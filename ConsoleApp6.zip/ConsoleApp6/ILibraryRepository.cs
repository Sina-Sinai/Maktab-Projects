﻿using static ConsoleApp6.Person;

namespace ConsoleApp6
{
    interface ILibraryRepository
    {
        static void AllBoroowed()
        {
        }
        static void AddBook()
        {
        }
        static void RemoveBook()
        {
        }
        static void ProntBook()
        {
        }
        static void BorrowBook(Person p)
        {
        }

        static void ReturnBook(Person p)
        {
        }

        static void GetListOfLibraryBooks()
        {
        }
        static void GetListOfUserBooks(Person p)
        {
        }
    }
}