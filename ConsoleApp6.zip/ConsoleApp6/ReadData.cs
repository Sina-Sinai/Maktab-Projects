﻿using System.Text.Json;

namespace ConsoleApp6
{
    internal class ReadData
    {
        public static Person Getpersonfromdatabase(string path)
        {
            // باگ داره دارم روش کار میکنم ولی سینتکس به نظر درست میاد
            var x = File.ReadAllText(path);
            Person personperson = JsonSerializer.Deserialize<Person>(x, JsonSerializerOptions.Default);
            return personperson;
        }

    }
}
