﻿namespace ConsoleApp6
{
    class ContactInfo
    {
        public ContactInfo(string? city, string? address, int? mobile, string email)
        {
            City = city;
            Address = address;
            Mobile = mobile;
            Email = email;
        }
        public string? City { get; set; }
        public string? Address { get; set; }
        public int? Mobile { get; set; }
        public string Email { get; set; }

    }
}