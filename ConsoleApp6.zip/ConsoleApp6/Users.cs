﻿namespace ConsoleApp6
{
    static class Users
    {
        public static List<Person> people = new List<Person>();
        static Users()
        {
            people = new List<Person>();
        }
        public static Person? CurrentUser { get; set; }
    }
}