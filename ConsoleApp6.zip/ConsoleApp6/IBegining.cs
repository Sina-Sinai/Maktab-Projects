﻿namespace ConsoleApp6
{

    interface IBegining
    {
        static void start()
        {
        }
        static void menu(Person p)
        {
        }
    }
}