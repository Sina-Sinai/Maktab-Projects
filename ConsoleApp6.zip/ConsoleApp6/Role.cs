﻿namespace ConsoleApp6
{

    partial class Person
    {
        public enum Role
        {
            member,
            manager
        }
    }
}