﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    internal class WriteData
    {
        public static void Write(string path, Person p)
        {
            string[] Data = {};
            Data.Append(JsonSerializer.Serialize(p));
            File.AppendAllLines(path, Data);
        }
    }
}
