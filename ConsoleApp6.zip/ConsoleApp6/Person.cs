﻿namespace ConsoleApp6
{
    partial class Person : IPerson
    {   
        public Person(string name, string family, int age, int gen, string password, int role)
        {
            Name = name;
            Family = family;
            Age = age;
            sexuality = (Gender)gen;
            Password = password;
            Rolee = (Role)role;
        }
        public Role Rolee { get; set; }
        public string Name { get; set; }
        public string Family { get; set; }
        public int Age { get; set; }

        public Gender sexuality { get; set; }
        public string Password { get; set; }

        public List<ContactInfo> Contacts = new List<ContactInfo>();
        public static List<Book> borrowed = new List<Book>();

    }
}