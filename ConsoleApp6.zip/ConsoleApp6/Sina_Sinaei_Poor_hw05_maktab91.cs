﻿using ConsoleApp6;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;

namespace ConsoleApp6
{
    internal static class Sina_Sinaei_Poor_hw04_maktab91    
    {
        public static DateTime shamsi(this DateTime date, string date1)
        {
            DateTime d = DateTime.Parse(date1);
            PersianCalendar sd = new PersianCalendar();
            string res = $@"{sd.GetYear(d)}/{sd.GetMonth(d)}/{sd.GetDayOfMonth(d)}";
            return Convert.ToDateTime(res);
        }
        static int[] insertation_sort(int[] arr)
        {
            int n = arr.Length;
            for (int i = 1; i < n; i++)
            {
                int j = i - 1;
                int key = arr[i];
                while(j >= 0 && arr[j] > key)
                {
                    arr[j+1] = arr[j];
                    j = j -1;
                }
                arr[j + 1] = key;
            }
            return arr;
        }

        static int binarySearch(int number, int[] arr)
        {
            int n = arr.Length;
            int start = 0;
            int end = n-1;
            while (number != arr[(end+start)/2])
            { 
                if (end - start == 1)
                {
                    if ( number == arr[end]) {
                        return end;
                    }
                    return -1;
                }
                else if (number > arr[(end + start) /2])
                {
                    start = (start + end) / 2;
                }
                else if ( number < arr[(end + start) / 2])
                {
                    end = (end + start) / 2;
                }
            }
            return (end + start) / 2;
            
        }

        static void Main(string[] args)
        {
            //string ddd = Console.ReadLine();
            //DateTime res = new DateTime();
            //res = res.shamsi(ddd);
            //Console.WriteLine(res);
            //--------------------------------------------------
            while (true)
            {
                Begining.start();
            }
            //--------------------------------------------------
            //int[] array = { 1, 7, 14, 20, 32, 55, 56 };
            //Console.WriteLine(binarySearch(20, array));
            //--------------------------------------------------
            //int n;
            //n = Convert.ToInt32(Console.ReadLine());
            //int[] arr = new int[n];

            //for (int i = 0; i < n; i++)
            //{
            //    arr[i] = Convert.ToInt32(Console.ReadLine());
            //}

            //foreach (var i in insertation_sort(arr))
            //{
            //    Console.Write(i + " ");
            //}
            //---------------------------------------------------
        }
    }
}