﻿namespace ConsoleApp6
{
    interface IAuthentication
    {
        
        static void Login(string email)
        {
        }

        static void Register()
        {
        }
    }
}