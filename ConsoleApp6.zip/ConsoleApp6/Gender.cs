﻿namespace ConsoleApp6
{
    partial class Person
    {
        public enum Gender
        {
            Male = 1,
            Female
        }
    }
}